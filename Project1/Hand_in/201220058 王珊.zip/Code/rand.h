#pragma once
#include <cstring>
#include <iostream>
#include <string>
#include <time.h>
using namespace std;

string getTime(); //获取本地时间
string getTime_0();
int Setid(); //随机数生成id
string new_id();
time_t getTime_value();
