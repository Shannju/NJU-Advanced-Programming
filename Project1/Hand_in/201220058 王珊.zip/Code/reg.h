
#pragma once
#include <iostream>
#include <string>
#include <regex>

using namespace std;
int reg_inum();
double reg_dnum();
string reg_name();
string reg_password();
string reg_con();
string reg_add();