#include "graphscene.h"


Map::Map()
{}

Map::Map(int r,int c ):colunm(c),row(r)
{
    for (int i = 0; i < colunm; ++i)
    {
        vector <int> tmp (row);
        a.push_back(tmp);
    }
    read_file();

}

void Map::init()
{
    for (int i = 0; i < colunm; ++i)
        for (int j = 0; j < row; ++j)
            a[i][j]= 0;
    write_file();

}

void Map::read_file()
{
    ifstream ifs;
    ifs.open(MAP_File, ios::in);
    if (!ifs.is_open())
    {
        Debug("file map.txt dont exist, new one created.")
                fstream ofs;
        ofs.open(MAP_File, ios::out);
        ofs.close();
        return;
    }
    for (int i = 0; i < colunm; ++i)
        for (int j = 0; j < row; ++j)
        {
            ifs >>  a[i][j] ;
            if (a[i][j] == 5)
                startPos =pair(i,j);
        }
    ifs.close();
}

void Map::write_file()
{
    fstream ofs;
    ofs.open(MAP_File, ios::out);
    for (int i = 0; i < colunm; ++i)
    {
        ofs << endl;
        for (int j = 0; j < row; ++j)
            ofs<< a[i][j] <<" ";
    }
    ofs.close();
}

void Map::print_file()
{
    for (int i = 0; i < colunm; ++i)
    {
        cerr <<endl;
        for (int j = 0; j < row; ++j)
            cerr << a[i][j];
    }
}

GraphScene::GraphScene(QObject *parent)
    : QGraphicsScene{parent},u(150),      d(30),      l(45),      r(30),      space(5),side(80)
{
    auto back_image_orgin = QImage(":/image/blackboard.png");
    auto  back_image = back_image_orgin.scaled(1160,650);
    QPixmap p =  QPixmap ::fromImage(*&back_image);
    addPixmap(p);
    init();
}

void GraphScene::init()
{
    //set Cards

    Card* c = new Card(this,":/image/yel.png",":/image/selected.png",30,0,QString(":/image/s_yel.png"),QString("专业课"));
    c->setPos(0,10);
    card_list.append(c);
   c = new Card(this,":/image/blue.png",":/image/selected.png",30,0,QString(":/image/s_blue.png"),QString("通识课"));
    c->setPos(80,10);
    card_list.append(c);
    c = new Card(this,":/image/green.png",":/image/selected.png",30,0,QString(":/image/s_green.png"),QString("体育课"));
    c->setPos(160,10);
    card_list.append(c);
     c = new Card(this,":/image/pink.png",":/image/selected.png",30,0,QString(":/image/s_pink.png"),QString("校庆"));
    c->setPos(240,10);
    card_list.append(c);

    c = new Card(this,":/image/ddl.png",":/image/selected.png",50,1,QString(":/image/s_red.png"),QString("Deadline"));//ddl
    c->setPos(320,10);
    card_list.append(c);
    c = new Card(this,":/image/buf4.png",":/image/selected.png",50,3,QString(":/image/heart.png"),QString("增加预算"));//词缀
    c->setPos(450,10);
    card_list.append(c);

    c = new Card(this,":/image/far1.png",":/image/selected.png",50,2,QString(":/image/far1.png"),QString("修铁丝网"));//远程
    c->setPos(610,10);
    card_list.append(c);
    c = new Card(this,":/image/far2.png",":/image/selected.png",50,2,QString(":/image/far2.png"),QString("新建食堂"));//远程
    c->setPos(680,10);
    card_list.append(c);
    c = new Card(this,":/image/far3.png",":/image/selected.png",50,2,QString(":/image/far3.png"),QString("绿化校园"));//远程
    c->setPos(740,10);
    card_list.append(c);

    c = new Card(this,":/image/buf1.png",":/image/selected.png",30,3,QString(""),QString("红榜转黑"));//词缀
    c->setPos(870,10);
    card_list.append(c);

    c = new Card(this,":/image/buf2.png",":/image/selected.png",30,3,QString(""),QString("次次点到"));//词缀
    c->setPos(960,10);
    card_list.append(c);

    c = new Card(this,":/image/buf3.png",":/image/selected.png",30,3,QString(""),QString("线上教学"));//词缀
    c->setPos(1080,10);
    card_list.append(c);



    m =new Map(12,5);//row col
    for (int i=0;i<m->colunm;i++)
        map.append(QList<gezi*>());
    load_map();
}

void GraphScene::load_map()
{
    for (int i =0;i<m->colunm;i++)
    {
        for (int j =0;j<m->row;j++)
        {
            int type =m->a[i][j];
            gezi* tmp = new gezi(this,i,j,type);
            map[i].append(tmp);
        }

    }
}

pair<int, int> GraphScene::get_abs(int r, int c)
{
    return pair(l+(space+side)*c,u+(space+side)*r);
}

pair<int, int> GraphScene::get_rela(int x, int y)
{
    return pair((y-u)/(space+side),(x-l)/(space+side));
}

gezi *GraphScene::get_gezi(int x, int y)
{
    pair<int, int>  r = get_rela(y,x);
    return map[r.first][r.second];
}

void GraphScene::advance(int phase)
{
    //    cerr << "rtry to generate.."<<endl;
    if (randomBool(4))
        newEnemy();

}

void GraphScene::newEnemy()
{
    int i= m->startPos.first;
    int j = m->startPos.second;
    int num = randomInt(0,4);
    auto* tmp = new student(this,Enemy_list[num],i,j);
    stu.append(tmp);
}

void GraphScene::addCard(Card *c)
{
    currentCard=c;
    c->onSelected();
    qDebug() << "currentcard updated";
}



