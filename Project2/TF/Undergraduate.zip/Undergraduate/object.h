﻿#ifndef OBJECT_H
#define OBJECT_H

#include <QGraphicsScene>
#include<Marcos.h>
#include<fstream>
#include <vector>
#include<QPixmap>
#include<Marcos.h>
#include<graphscene.h>
#include<QMouseEvent>
#include <QImageReader>
#include<QGraphicsPixmapItem>


class object: public QGraphicsPixmapItem
{
protected:
    int side;
    int tcount;
    int interval;

public:

    QList<Card*> buff;
    GraphScene *s;

    pair<int,int> absPos;
    pair<int,int> relaPos;
    int health,clever,mental;

    void setPosition(int r,int c);
    virtual QString getString();

    object(GraphScene *s, const QString &icon,int side,int i,int j);

    void setLife(int health, int clever, int mental);
    void changeLife(int health, int clever, int mental);

    virtual void changePic( const QString& s);
    QRectF boundingRect( )const;
    virtual void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget = Q_NULLPTR);
    virtual void advance(int phase);
    virtual void onSlow(){};
    virtual void onFast(){};

};


class mover:public object
{
protected:

    pair<int,int> dir;
    int count;//位置计数

public:
    int speed;
    mover(GraphScene *s, const QString &icon, int side,int i, int j);
    virtual   void updatePos();
    void setSpeed(int s){speed =s;};
    virtual void onSlow();
    virtual void onFast();
};


class fly:public mover
{
public:
    void setDir(int x,int y ){dir=pair(x,y);};
    fly(GraphScene *s, const QString &icon, int side, int i, int j);
    QString getString(){return QString("");};
    virtual void updatePos();
    virtual void onSlow(){};
    virtual void onFast();
};

class student:public mover
{
protected:

    bool islive();

    int count;
public:
    student(GraphScene *s, const QString &icon,int i,int j);
    void hurt(fly*f);
    QString getString();
    virtual void onSlow();
    virtual void onFast();

};




class gezi: public object
{
protected:
    const int type;//7 ddl
    QString n;
    int durtime;
public:
    gezi( GraphScene *s, int i, int j,int type) ;
    int tower_type;
    void init();

    int getType(){return type;};
    virtual QString getString();
    void act(student* s);

    void pen(int x,int y);

    bool onClick(Card* c);
    bool addCard(Card* c);
    void deCard();
    void addBuf(Card* c);
    void deBuf(Card* c);
    void onClickright();

    void changePic( QString s);

    //    virtual void advance(int phase);
    virtual void onSlow();
    virtual void onFast();
};


class Card:  public QGraphicsPixmapItem
{
protected:
    QString icon;
    int side;

    QString icon_selected;



    GraphScene *s;
public:
    int interval, adder ;
    bool isAll;
    QString name;
    Card(GraphScene *s, const QString &icon, const QString &icon_selected, int side, int isBuf, const QString &picture,const QString &name);


    int isBuf;//0近战  1 ddl  2 远程 3 buf
    QString picture;

    virtual QString getString();


    void changePic(QString s);
    QRectF boundingRect( )const;
    virtual void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget = Q_NULLPTR);
    virtual void advance(int phase);
    void onSelected();
    void deSelcted();

};

#endif // OBJECT_H
