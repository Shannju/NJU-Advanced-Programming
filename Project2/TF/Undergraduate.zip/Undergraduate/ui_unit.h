/********************************************************************************
** Form generated from reading UI file 'unit.ui'
**
** Created by: Qt User Interface Compiler version 6.3.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_UNIT_H
#define UI_UNIT_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QWidget>
#include <square.h>

QT_BEGIN_NAMESPACE

class Ui_Unit
{
public:
    QWidget *mainWidget;
    QHBoxLayout *horizontalLayout;
    QLabel *activity;
    Square *icon;

    void setupUi(QWidget *Unit)
    {
        if (Unit->objectName().isEmpty())
            Unit->setObjectName(QString::fromUtf8("Unit"));
        Unit->resize(363, 253);
        Unit->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        mainWidget = new QWidget(Unit);
        mainWidget->setObjectName(QString::fromUtf8("mainWidget"));
        mainWidget->setGeometry(QRect(0, 0, 92, 42));
        horizontalLayout = new QHBoxLayout(mainWidget);
        horizontalLayout->setSpacing(0);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalLayout->setSizeConstraint(QLayout::SetNoConstraint);
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        activity = new QLabel(mainWidget);
        activity->setObjectName(QString::fromUtf8("activity"));
        activity->setMinimumSize(QSize(42, 0));

        horizontalLayout->addWidget(activity);

        icon = new Square(mainWidget);
        icon->setObjectName(QString::fromUtf8("icon"));

        horizontalLayout->addWidget(icon);

        horizontalLayout->setStretch(0, 3);
        horizontalLayout->setStretch(1, 2);

        retranslateUi(Unit);

        QMetaObject::connectSlotsByName(Unit);
    } // setupUi

    void retranslateUi(QWidget *Unit)
    {
        Unit->setWindowTitle(QCoreApplication::translate("Unit", "Form", nullptr));
        activity->setText(QCoreApplication::translate("Unit", "\346\264\273\345\212\250", nullptr));
        icon->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class Unit: public Ui_Unit {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_UNIT_H
