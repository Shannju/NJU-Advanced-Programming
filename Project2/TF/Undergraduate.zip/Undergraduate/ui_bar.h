/********************************************************************************
** Form generated from reading UI file 'bar.ui'
**
** Created by: Qt User Interface Compiler version 6.3.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_BAR_H
#define UI_BAR_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Bar
{
public:
    QGridLayout *gridLayout;
    QHBoxLayout *horizontalLayout;
    QLabel *icon;
    QVBoxLayout *verticalLayout;
    QLabel *bar_life;
    QLabel *bar_zhishi;
    QLabel *bar_phi;

    void setupUi(QWidget *Bar)
    {
        if (Bar->objectName().isEmpty())
            Bar->setObjectName(QString::fromUtf8("Bar"));
        Bar->resize(229, 96);
        gridLayout = new QGridLayout(Bar);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        gridLayout->setContentsMargins(0, 0, 0, 0);
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        icon = new QLabel(Bar);
        icon->setObjectName(QString::fromUtf8("icon"));

        horizontalLayout->addWidget(icon);

        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        bar_life = new QLabel(Bar);
        bar_life->setObjectName(QString::fromUtf8("bar_life"));
        bar_life->setStyleSheet(QString::fromUtf8("background-color: rgb(195, 0, 0);\n"
"color: rgb(255, 255, 255);"));

        verticalLayout->addWidget(bar_life);

        bar_zhishi = new QLabel(Bar);
        bar_zhishi->setObjectName(QString::fromUtf8("bar_zhishi"));
        bar_zhishi->setStyleSheet(QString::fromUtf8("background-color: rgb(85, 85, 127);\n"
"color: rgb(255, 255, 255);"));

        verticalLayout->addWidget(bar_zhishi);

        bar_phi = new QLabel(Bar);
        bar_phi->setObjectName(QString::fromUtf8("bar_phi"));
        bar_phi->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 85, 127);\n"
"color: rgb(255, 255, 255);"));

        verticalLayout->addWidget(bar_phi);


        horizontalLayout->addLayout(verticalLayout);


        gridLayout->addLayout(horizontalLayout, 0, 0, 1, 1);


        retranslateUi(Bar);

        QMetaObject::connectSlotsByName(Bar);
    } // setupUi

    void retranslateUi(QWidget *Bar)
    {
        Bar->setWindowTitle(QCoreApplication::translate("Bar", "Form", nullptr));
        icon->setText(QCoreApplication::translate("Bar", "TextLabel", nullptr));
        bar_life->setText(QCoreApplication::translate("Bar", "\347\224\237\345\221\275", nullptr));
        bar_zhishi->setText(QCoreApplication::translate("Bar", "\347\237\245\350\257\206", nullptr));
        bar_phi->setText(QCoreApplication::translate("Bar", "\345\255\230\345\234\250\344\270\273\344\271\211\345\215\261\346\234\272", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Bar: public Ui_Bar {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_BAR_H
