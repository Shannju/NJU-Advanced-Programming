#ifndef RANDOM_H
#define RANDOM_H

#include <cstdlib>
#include <QTime>


int randomInt(int a, int b);
int randomBool(int a);
#endif // RANDOM_H
