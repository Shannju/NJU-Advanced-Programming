/********************************************************************************
** Form generated from reading UI file 'card.ui'
**
** Created by: Qt User Interface Compiler version 6.3.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CARD_H
#define UI_CARD_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QWidget>
#include <square.h>

QT_BEGIN_NAMESPACE

class Ui_Card
{
public:
    QWidget *mainWidget;
    QHBoxLayout *horizontalLayout;
    Square *icon;
    QLabel *intro;

    void setupUi(QWidget *Card)
    {
        if (Card->objectName().isEmpty())
            Card->setObjectName(QString::fromUtf8("Card"));
        Card->resize(465, 249);
        mainWidget = new QWidget(Card);
        mainWidget->setObjectName(QString::fromUtf8("mainWidget"));
        mainWidget->setGeometry(QRect(0, 0, 199, 85));
        horizontalLayout = new QHBoxLayout(mainWidget);
        horizontalLayout->setSpacing(0);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalLayout->setSizeConstraint(QLayout::SetDefaultConstraint);
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        icon = new Square(mainWidget);
        icon->setObjectName(QString::fromUtf8("icon"));
        icon->setEnabled(true);
        icon->setMaximumSize(QSize(85, 16777215));
        icon->setStyleSheet(QString::fromUtf8(""));

        horizontalLayout->addWidget(icon);

        intro = new QLabel(mainWidget);
        intro->setObjectName(QString::fromUtf8("intro"));
        intro->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 170, 127);"));
        intro->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignTop);

        horizontalLayout->addWidget(intro);


        retranslateUi(Card);

        QMetaObject::connectSlotsByName(Card);
    } // setupUi

    void retranslateUi(QWidget *Card)
    {
        Card->setWindowTitle(QCoreApplication::translate("Card", "Form", nullptr));
        icon->setText(QString());
        intro->setText(QCoreApplication::translate("Card", "introduction", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Card: public Ui_Card {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CARD_H
