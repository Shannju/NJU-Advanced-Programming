/********************************************************************************
** Form generated from reading UI file 'top.ui'
**
** Created by: Qt User Interface Compiler version 6.3.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_TOP_H
#define UI_TOP_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>
#include "card.h"

QT_BEGIN_NAMESPACE

class Ui_Top
{
public:
    QWidget *layoutWidget;
    QHBoxLayout *horizontalLayout;
    QLabel *week;
    QLabel *pic;
    QVBoxLayout *verticalLayout;
    Card *widget;
    Card *widget_2;
    Card *widget_3;

    void setupUi(QWidget *Top)
    {
        if (Top->objectName().isEmpty())
            Top->setObjectName(QString::fromUtf8("Top"));
        Top->resize(917, 474);
        layoutWidget = new QWidget(Top);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        layoutWidget->setGeometry(QRect(170, 150, 591, 131));
        horizontalLayout = new QHBoxLayout(layoutWidget);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        week = new QLabel(layoutWidget);
        week->setObjectName(QString::fromUtf8("week"));

        horizontalLayout->addWidget(week);

        pic = new QLabel(layoutWidget);
        pic->setObjectName(QString::fromUtf8("pic"));

        horizontalLayout->addWidget(pic);

        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        widget = new Card(layoutWidget);
        widget->setObjectName(QString::fromUtf8("widget"));
        widget->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));

        verticalLayout->addWidget(widget);

        widget_2 = new Card(layoutWidget);
        widget_2->setObjectName(QString::fromUtf8("widget_2"));

        verticalLayout->addWidget(widget_2);

        widget_3 = new Card(layoutWidget);
        widget_3->setObjectName(QString::fromUtf8("widget_3"));

        verticalLayout->addWidget(widget_3);


        horizontalLayout->addLayout(verticalLayout);

        horizontalLayout->setStretch(0, 1);
        horizontalLayout->setStretch(1, 1);
        horizontalLayout->setStretch(2, 4);

        retranslateUi(Top);

        QMetaObject::connectSlotsByName(Top);
    } // setupUi

    void retranslateUi(QWidget *Top)
    {
        Top->setWindowTitle(QCoreApplication::translate("Top", "Form", nullptr));
        week->setText(QCoreApplication::translate("Top", "1/4 Week", nullptr));
        pic->setText(QCoreApplication::translate("Top", "TextLabel", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Top: public Ui_Top {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_TOP_H
