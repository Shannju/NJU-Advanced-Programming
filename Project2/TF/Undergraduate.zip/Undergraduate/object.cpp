#include "object.h"
#include "qpainter.h"
#include<QLabel>


QRectF object::boundingRect() const
{
    return QRectF(0,0,side,side);
}

void object::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget)
{
    setPos(absPos.first,absPos.second);
    //    painter->drawPixmap(0,0,this->pic);
    painter->drawPixmap(0,0,this->pixmap());
}

void object::advance(int phase)
{
    tcount ++;
    if (tcount==interval)
    {
        tcount=0;
        onSlow();
    }
    onFast();
}


QString object::getString()
{
    return QString("Empty Object");
}


object::object(GraphScene *s, const QString &icon, int side,int i,int j) : s(s),
    side(side),interval(100),tcount(0)
{
    setPixmap(QPixmap(icon).scaled(side,side));
    setPosition(i,j);
    s->addItem(this);

}

void object::setPosition(int r, int c)
{
    relaPos.first=r;
    relaPos.second=c;
    absPos=s->get_abs(r,c);

}

bool student::islive()
{
    return health>0&&mental>0&&clever>0;
}



void object::setLife(int health, int clever, int mental)
{
    this->health=health;
    this->clever=clever;
    this->mental=mental;
}

void object::changeLife(int health, int clever, int mental)
{
    this->health+=health;
    this->clever+=clever;
    this->mental+=mental;
    setToolTip(getString());
}

void object::changePic(const QString &s)
{
    setPixmap(QPixmap(s).scaled(side,side));
}

QString student::getString()
{
    QString s;
    if (health<30|| mental<30|| clever<30)
        s+=QString("【退学边缘】 ");
    else if (health<60|| mental<60|| clever<60)
        s+=QString("【得过且过】 ");
    else
        s+=QString("【勃勃生机】 ");
    s+=QString("健康 ")+QString::number(health)+QString(" 智慧 ")+QString::number(clever)+QString(" 存在 ")+QString::number(mental);
    return s;
}


void student::onSlow()
{

}

void student::onFast()
{
    if (s->map[relaPos.first][relaPos.second]->tower_type==1)
    {
        speed =0;
    }
    if (s->map[relaPos.first][relaPos.second]->getType()==6)
    {
        hide();
    }
    QList<QGraphicsItem *> list=collidingItems(Qt::IntersectsItemBoundingRect);
    for (QGraphicsItem  * i :list)
    {
        if (i->zValue()==3)
        {
            fly* tmp = qgraphicsitem_cast<fly*>(i);
            changeLife(tmp->health,tmp->clever,tmp->mental);

            delete tmp;
        }
    }
    updatePos();

}

void mover::updatePos()
{
    //    cerr<<"here is speed " << this << speed<<endl;
    absPos.first+=dir.first*speed;
    absPos.second+=dir.second*speed;
    relaPos=s->get_rela(absPos.first,absPos.second);
    setPos(absPos.first,absPos.second);
    count +=max(dir.first,dir.second)*speed;
    if (count>=(side+5))
    {
        count = 0;
        int ge= s->map[relaPos.first][relaPos.second]->getType();

        dir=Dir_list[ge];
        return;
    }

}


void mover::onSlow()
{

}

void mover::onFast()
{
    updatePos();
    update();
}



student::student( GraphScene *s, const QString &icon, int i, int j) :mover(s, icon, 80, i, j),count(0)
{
    this->setZValue(2);
    this->dir=pair(1,0);
    speed =1;
    setLife(90,randomInt(80,100),randomInt(80,100));
    setToolTip(getString());
}

void student::hurt(fly *f)
{

}

gezi::gezi(GraphScene *s, int i, int j, int type):object(s, Color_list[type], 80, i, j),
    type(type),durtime(0)
{
    if (type==0)
        n=QString("空格");
    else
        n=QString("空闲时间");
    tower_type=-1;
    setZValue(1);
    setLife(-1,-1,-1);
    setToolTip(getString());

}

void gezi::init()
{
    if (type==0)
        n=QString("空格");
    else
        n=QString("空闲时间");
    setLife(-1,-1,-1);
    changePic(Color_list[type]);
    buff.empty();
}

QString gezi::getString()
{
    QString s=n;
    for (Card*i:buff)
    {
        s+=QString (" ");
        s+=i->name;
        qDebug()<<buff.size();
    }
    return s;
}

void gezi::act(student *s)
{


}

void gezi::pen(int x, int y)
{
    auto* f = new fly(s,QString(":/image/heart.png"),10,relaPos.first,relaPos.second);
    f->setDir(x,y);
}

bool gezi::onClick(Card *c)
{

    if (c->picture!="")
        changePic(c->picture);
    if (c->isBuf==0)//class
    {
        //        changePic(c->picture);
            n=c->name;
        tower_type=c->isBuf;
        durtime= 10000;
            setToolTip(getString());
        return 1;

    }
    else if (c->isBuf==1)//ddl
    {
        //        changePic(c->picture);
            n=c->name;
        tower_type=c->isBuf;
        durtime= type*100;
            setToolTip(getString());
        return 1;

    }
    else if (c->isBuf==2)//buildings
    {
        if (type==0)
        {
            //            changePic(c->picture);
                n=c->name;
            tower_type=c->isBuf;
            durtime= 10000;
                setToolTip(getString());
            return 1;

        }}
    else if (c->isBuf==3)//buf
    {
        if (tower_type==0||tower_type==1)//
        {
            qDebug()<<"getbuf";
            addBuf(c);
            durtime= 10000;
            setToolTip(getString());
            return 1;
        }
    }

    return 0;

}


void gezi::addBuf(Card *c)
{
    if(buff.size()<2)
    {
        buff.append(c);
    }
    else{
        cerr<<"buf full"<<endl;
    }
}

void gezi::onClickright()
{
    if(buff.size()>0)
    {
        Card *c=buff.takeLast();
        buff.removeLast();
    }
    else{
        cerr<<"buf all removes"<<endl;
    }

}

void gezi::changePic(QString s)
{
    setPixmap(QPixmap(s).scaled(side,side));
}

void gezi::onSlow()
{
    QList<QGraphicsItem *> list=collidingItems(Qt::IntersectsItemBoundingRect);
    for (QGraphicsItem  * i :list)
    {
        if (i->zValue()==2)
        {
            student* tmp = qgraphicsitem_cast<student*>(i);
            tmp->changeLife(health,clever,mental);
            if(tower_type == 1)
            {
                durtime-=tmp->clever%30;
                tmp->speed=0;
            }
            if (durtime<=0)
            {
                tower_type=0;
                tmp->setSpeed(1);
                init();
            }
        }
    }
    if (tower_type==2)
    {
        pen(1,1);
        pen(-1,1);
        pen(-1,-1);
        pen(1,-1);
    }


}

void gezi::onFast()
{
    QList<QGraphicsItem *> list=collidingItems(Qt::IntersectsItemBoundingRect);
    for (QGraphicsItem  * i :list)
    {
        if (i->zValue()==2)
        {
            student* tmp = qgraphicsitem_cast<student*>(i);
            if(tower_type == 1)
            {
                //                durtime-=tmp->clever%30;
                tmp->speed=0;
            }
        }
    }
}


mover::mover(GraphScene *s, const QString &icon,int side, int i, int j) : object(s, icon,side, i, j),
    count(0)
{
    setSpeed(1);
    this->dir=pair(0,0);
}




Card::Card(GraphScene *s, const QString &icon, const QString &icon_selected, int side, int isBuf, const QString &picture, const QString &name):
    side(side),icon(icon),
    icon_selected(icon_selected),
    isBuf(isBuf),
    picture(picture),
    s(s),
    name(name)
{
    setZValue(1);
    QPixmap pic(icon);
    setPixmap(pic.scaled(pic.width()*side/pic.height(),side));
    s->addItem(this);
}


QString Card::getString()
{
}

void Card::changePic(QString s)
{
    QPixmap pic(s);
    setPixmap(pic.scaled(pic.width()*side/pic.height(),side));
}

QRectF Card::boundingRect() const
{
    QPixmap pic(icon);
    return QRectF(0,0,pic.width()*side/pic.height(),side);
}

void Card::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget)
{
    painter->drawPixmap(0,0,this->pixmap());
}

void Card::advance(int phase)
{

}

void Card::onSelected()
{
    changePic(icon_selected);
}

void Card::deSelcted()
{
    changePic(icon);
}



fly::fly(GraphScene *s, const QString &icon, int side, int i, int j) : mover(s, icon, side, i, j)
{
    setZValue(3);
    speed =1;

    this->dir=pair(1,0);
    speed =1;
    setLife(90,randomInt(80,100),randomInt(80,100));
    setToolTip(getString());
    setCursor(Qt::OpenHandCursor);    //改变光标形状,光标变为了手型

}

void fly::updatePos()
{
    absPos.first+=dir.first*speed;
    absPos.second+=dir.second*speed;
    relaPos=s->get_rela(absPos.first,absPos.second);
    setPos(absPos.first,absPos.second);
    if (absPos.second<130||absPos.second>630||absPos.first<0||absPos.first>1130)
    {
        speed=0;
        hide();
    }

}

void fly::onFast()
{
    updatePos();
    update();
}
