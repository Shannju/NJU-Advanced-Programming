#ifndef TIMER_H
#define TIMER_H
#include <QTimer>

void setTimer();
#endif // TIMER_H
