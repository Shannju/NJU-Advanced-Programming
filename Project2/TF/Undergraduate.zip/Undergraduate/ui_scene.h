/********************************************************************************
** Form generated from reading UI file 'scene.ui'
**
** Created by: Qt User Interface Compiler version 6.3.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SCENE_H
#define UI_SCENE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QFormLayout>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>
#include <mygraphicsview.h>

QT_BEGIN_NAMESPACE

class Ui_Scene
{
public:
    QFormLayout *formLayout;
    QVBoxLayout *verticalLayout;
    MYGraphicsView *graphicsView;

    void setupUi(QWidget *Scene)
    {
        if (Scene->objectName().isEmpty())
            Scene->setObjectName(QString::fromUtf8("Scene"));
        Scene->resize(1193, 750);
        Scene->setStyleSheet(QString::fromUtf8(""));
        formLayout = new QFormLayout(Scene);
        formLayout->setObjectName(QString::fromUtf8("formLayout"));
        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        graphicsView = new MYGraphicsView(Scene);
        graphicsView->setObjectName(QString::fromUtf8("graphicsView"));
        graphicsView->setStyleSheet(QString::fromUtf8("border-color: rgb(255, 255, 255);"));

        verticalLayout->addWidget(graphicsView);

        verticalLayout->setStretch(0, 6);

        formLayout->setLayout(0, QFormLayout::SpanningRole, verticalLayout);


        retranslateUi(Scene);

        QMetaObject::connectSlotsByName(Scene);
    } // setupUi

    void retranslateUi(QWidget *Scene)
    {
        Scene->setWindowTitle(QCoreApplication::translate("Scene", "Form", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Scene: public Ui_Scene {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SCENE_H
