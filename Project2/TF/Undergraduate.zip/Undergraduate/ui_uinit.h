/********************************************************************************
** Form generated from reading UI file 'unit.ui'
**
** Created by: Qt User Interface Compiler version 6.3.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_UINIT_H
#define UI_UINIT_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Unit
{
public:
    QLabel *label_4;
    QLabel *label_3;
    QLabel *label;
    QLabel *label_2;

    void setupUi(QWidget *Unit)
    {
        if (Unit->objectName().isEmpty())
            Unit->setObjectName(QString::fromUtf8("Unit"));
        Unit->resize(400, 300);
        label_4 = new QLabel(Unit);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(269, 80, 69, 83));
        label_3 = new QLabel(Unit);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(195, 80, 68, 83));
        label = new QLabel(Unit);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(45, 80, 69, 83));
        label_2 = new QLabel(Unit);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(120, 80, 69, 83));

        retranslateUi(Unit);

        QMetaObject::connectSlotsByName(Unit);
    } // setupUi

    void retranslateUi(QWidget *Unit)
    {
        Unit->setWindowTitle(QCoreApplication::translate("Unit", "Form", nullptr));
        label_4->setText(QCoreApplication::translate("Unit", "Existence", nullptr));
        label_3->setText(QCoreApplication::translate("Unit", "Knowledge", nullptr));
        label->setText(QCoreApplication::translate("Unit", "1/4 Week", nullptr));
        label_2->setText(QCoreApplication::translate("Unit", "Life", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Unit: public Ui_Unit {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_UINIT_H
