#include "scene.h"

Scene::Scene(QWidget *parent) :
    QWidget(parent)
{
    ui = new Ui::Scene;
    ui->setupUi(this);
    setFixedSize(1193,795);




}

